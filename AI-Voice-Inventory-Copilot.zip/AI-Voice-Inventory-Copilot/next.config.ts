import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  // Native module: must not be bundled (ARCHITECTURE §12).
  serverExternalPackages: ["better-sqlite3"],
};

export default nextConfig;
