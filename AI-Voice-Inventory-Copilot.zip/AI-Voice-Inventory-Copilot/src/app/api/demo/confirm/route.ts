import { z } from "zod";
import { demoDb } from "@/server/demo/db";
import { applyChange } from "@/server/domain/inventory";
import { fail, ok } from "@/server/http/envelope";
import { withRequestId } from "@/server/http/withRequestId";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const body = z.object({
  productId: z.string().min(1),
  op: z.enum(["add", "remove"]),
  quantity: z.number().positive().max(1_000_000),
  unit: z.string().min(1).max(20),
  via: z.enum(["mic", "typed"]),
});

/** The only write path: re-validated server-side, applied atomically with a ledger row. */
export const POST = withRequestId(async (req) => {
  const parsed = body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return fail(400, "bad_request", "That confirmation wasn't valid.");
  const result = applyChange(demoDb(), parsed.data);
  return result.ok ? ok(result) : fail(422, result.code, result.message);
});
