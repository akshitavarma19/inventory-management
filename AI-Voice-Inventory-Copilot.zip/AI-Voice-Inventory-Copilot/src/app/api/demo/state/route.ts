import { demoDb } from "@/server/demo/db";
import { getState } from "@/server/domain/inventory";
import { ok } from "@/server/http/envelope";
import { withRequestId } from "@/server/http/withRequestId";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export const GET = withRequestId(() => ok(getState(demoDb())));
