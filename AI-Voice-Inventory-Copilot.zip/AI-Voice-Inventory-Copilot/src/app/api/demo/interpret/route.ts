import { z } from "zod";
import { demoDb } from "@/server/demo/db";
import { getCatalog } from "@/server/domain/inventory";
import { fail, ok } from "@/server/http/envelope";
import { withRequestId } from "@/server/http/withRequestId";
import { interpret } from "@/server/voice/interpret";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const body = z.object({ text: z.string().min(1).max(300) });

/** Read-only: proposes an interpretation. Never changes stock. */
export const POST = withRequestId(async (req) => {
  const parsed = body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return fail(400, "bad_request", "Please provide the command text.");
  const result = interpret(parsed.data.text, getCatalog(demoDb()));
  return ok(result);
});
