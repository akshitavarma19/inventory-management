import { demoDb } from "@/server/demo/db";
import { undoLast } from "@/server/domain/inventory";
import { fail, ok } from "@/server/http/envelope";
import { withRequestId } from "@/server/http/withRequestId";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export const POST = withRequestId(() => {
  const result = undoLast(demoDb());
  return result.ok ? ok(result) : fail(422, result.code, result.message);
});
