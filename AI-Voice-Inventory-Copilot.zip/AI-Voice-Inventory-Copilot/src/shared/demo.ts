// DTOs shared by the demo API and the UI (types only).

export interface ProductView {
  id: string;
  name: string;
  qty: number; // in the display unit
  unit: string; // display unit label, e.g. "bags", "kg"
  stockText: string; // "20 bags"
  low: boolean;
  thresholdText: string; // "10 bags"
}

export interface TxnView {
  id: string;
  productName: string;
  deltaText: string; // "+5 bags" / "-2 bags"
  stockAfterText: string;
  kind: "add" | "remove" | "undo";
  source: string;
  createdAt: string;
  reverted: boolean;
}

export interface StateView {
  shopName: string;
  products: ProductView[];
  recent: TxnView[];
  undoTarget: { id: string; label: string } | null;
}

export type Op = "add" | "remove";

export interface InterpretationView {
  productId: string;
  productName: string;
  op: Op;
  quantity: number;
  unit: string; // canonical unit, e.g. "bag"
  unitAssumed: boolean;
  summary: string; // "Add 5 bags of Rice"
  stockBeforeText: string;
  stockAfterText: string;
  willBeLow: boolean;
}
