import type { Database } from "better-sqlite3";
import { getDb } from "@/server/db/connection";
import { ensureDemoData } from "@/server/domain/inventory";

/** DB handle with the demo shop guaranteed to exist. */
export function demoDb(): Database {
  const db = getDb();
  ensureDemoData(db);
  return db;
}
