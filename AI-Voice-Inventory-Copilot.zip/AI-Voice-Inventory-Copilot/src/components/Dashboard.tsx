"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type { InterpretationView, StateView } from "@/shared/demo";

type Envelope<T> = { ok: true; data: T } | { ok: false; error: { code: string; message: string } };
type InterpretData = { ok: true; interpretation: InterpretationView } | { ok: false; code: string; message: string };

interface SRResultEvent {
  results: { length: number; [i: number]: { [j: number]: { transcript: string }; isFinal: boolean } };
}
interface SR {
  lang: string;
  interimResults: boolean;
  continuous: boolean;
  maxAlternatives: number;
  start(): void;
  stop(): void;
  onstart: (() => void) | null;
  onresult: ((e: SRResultEvent) => void) | null;
  onerror: ((e: { error: string }) => void) | null;
  onend: (() => void) | null;
}
type SRCtor = new () => SR;

const LANGS = [
  { code: "en-IN", label: "EN" },
  { code: "te-IN", label: "తెలుగు" },
  { code: "hi-IN", label: "हिन्दी" },
];

const EXAMPLES = ["Add 5 bags of rice", "Remove 2 bags of rice", "rice 5 add", "రెండు bags rice add cheyyi", "Sugar 3 kg sold", "Oil 4 bottles vachindi"];

function speechCtor(): SRCtor | undefined {
  const w = window as unknown as { SpeechRecognition?: SRCtor; webkitSpeechRecognition?: SRCtor };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition;
}

/** Permission/device failures from getUserMedia — tells "blocked" apart from "no microphone" and "busy". */
function describeMediaError(err: unknown): string {
  const name = err instanceof Error ? err.name : "Error";
  const tail = ` (${name}${err instanceof Error && err.message ? `: ${err.message}` : ""})`;
  switch (name) {
    case "NotAllowedError":
    case "SecurityError":
      return "Microphone permission is blocked. Click the 🔒 icon in the address bar, allow Microphone, and try again — or type your command." + tail;
    case "NotFoundError":
    case "OverconstrainedError":
      return "No microphone was found. Plug one in or enable it (Windows Settings → Privacy → Microphone), or type your command." + tail;
    case "NotReadableError":
    case "AbortError":
      return "The microphone is busy or unavailable — another app may be using it. Close it and try again, or type your command." + tail;
    default:
      return "Couldn't access the microphone." + tail;
  }
}

/** SpeechRecognition error codes → plain language plus the raw code, so the real cause is never hidden. */
function describeSpeechError(code: string, langCode: string): string {
  const tail = ` (error: ${code})`;
  switch (code) {
    case "not-allowed":
    case "service-not-allowed":
      return "The browser blocked speech recognition. Allow the microphone for this site (🔒 in the address bar). Some browser settings or policies also block the speech service. Or type your command." + tail;
    case "audio-capture":
      return "No working microphone was detected. Check that one is connected and selected as the input device, or type your command." + tail;
    case "network":
      return "Speech recognition couldn't reach the browser's speech service. Chrome and Edge send your voice to an online service, so this needs internet that isn't blocked (a VPN, firewall or privacy extension can cause this). Check your connection and try again — or type your command." + tail;
    case "no-speech":
      return "I didn't hear anything. Tap the mic and speak, or type your command." + tail;
    case "language-not-supported":
      return `This browser can't recognise ${langCode}. Try English (EN), or type your command.` + tail;
    default:
      return "Speech recognition failed." + tail;
  }
}

async function api<T>(path: string, init?: RequestInit): Promise<Envelope<T>> {
  try {
    const res = await fetch(path, { ...init, headers: { "content-type": "application/json" }, cache: "no-store" });
    return (await res.json()) as Envelope<T>;
  } catch {
    return { ok: false, error: { code: "network", message: "Can't reach the server. Try again in a moment." } };
  }
}

export function Dashboard() {
  const [state, setState] = useState<StateView | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [pending, setPending] = useState<{ i: InterpretationView; via: "mic" | "typed"; said: string } | null>(null);
  const [problem, setProblem] = useState<string | null>(null);
  const [toast, setToast] = useState<{ message: string; canUndo: boolean; tone: "ok" | "info" } | null>(null);
  const [flashId, setFlashId] = useState<string | null>(null);
  const [micSupported, setMicSupported] = useState(false);
  const [listening, setListening] = useState(false);
  const [micStarting, setMicStarting] = useState(false);
  const [lang, setLang] = useState("en-IN");
  const recRef = useRef<SR | null>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const refresh = useCallback(async () => {
    const r = await api<StateView>("/api/demo/state");
    if (r.ok) {
      setState(r.data);
      setLoadError(null);
    } else setLoadError(r.error.message);
  }, []);

  useEffect(() => {
    // Initial data load + client-only feature detection (avoids a hydration mismatch).
    /* eslint-disable react-hooks/set-state-in-effect */
    void refresh();
    setMicSupported(Boolean(speechCtor()));
    /* eslint-enable react-hooks/set-state-in-effect */
  }, [refresh]);

  const showToast = (message: string, canUndo: boolean, tone: "ok" | "info" = "ok") => {
    if (toastTimer.current) clearTimeout(toastTimer.current);
    setToast({ message, canUndo, tone });
    toastTimer.current = setTimeout(() => setToast(null), 9000);
  };

  const understand = useCallback(async (input: string, via: "mic" | "typed") => {
    const said = input.trim();
    if (!said) return;
    setBusy(true);
    setProblem(null);
    setPending(null);
    setToast(null);
    const r = await api<InterpretData>("/api/demo/interpret", { method: "POST", body: JSON.stringify({ text: said }) });
    setBusy(false);
    if (!r.ok) return setProblem(r.error.message);
    if (r.data.ok) setPending({ i: r.data.interpretation, via, said });
    else setProblem(r.data.message);
  }, []);

  const flash = (id: string) => {
    setFlashId(id);
    setTimeout(() => setFlashId(null), 1600);
  };

  const confirm = async () => {
    if (!pending) return;
    setBusy(true);
    const { i, via } = pending;
    const r = await api<{ message: string; productId: string }>("/api/demo/confirm", {
      method: "POST",
      body: JSON.stringify({ productId: i.productId, op: i.op, quantity: i.quantity, unit: i.unit, via }),
    });
    setBusy(false);
    setPending(null);
    if (r.ok) {
      setText("");
      flash(r.data.productId);
      await refresh();
      showToast(r.data.message, true);
    } else setProblem(r.error.message);
  };

  const undo = async () => {
    setBusy(true);
    const r = await api<{ message: string; productId: string }>("/api/demo/undo", { method: "POST", body: "{}" });
    setBusy(false);
    if (r.ok) {
      flash(r.data.productId);
      await refresh();
      showToast(r.data.message, false, "info");
    } else showToast(r.error.message, false, "info");
  };

  const toggleMic = async () => {
    if (listening) return recRef.current?.stop();
    if (micStarting) return;
    setProblem(null);

    const Ctor = speechCtor();
    if (!Ctor) {
      return setProblem(
        "This browser doesn't support speech recognition (the Web Speech API). Use Chrome or Edge on desktop or Android — or type your command.",
      );
    }
    if (!window.isSecureContext) {
      return setProblem(
        `The microphone only works on https:// or http://localhost — this page is ${window.location.origin}. Open it via localhost, or type your command.`,
      );
    }

    // Ask for microphone permission up front, so "blocked" and "no microphone" are reported as such
    // instead of being lumped in with speech-service errors.
    if (navigator.mediaDevices?.getUserMedia) {
      setMicStarting(true);
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        stream.getTracks().forEach((t) => t.stop());
      } catch (err) {
        setMicStarting(false);
        return setProblem(describeMediaError(err));
      }
      setMicStarting(false);
    }

    const rec = new Ctor();
    rec.lang = lang;
    rec.interimResults = true;
    rec.continuous = false;
    rec.maxAlternatives = 1;
    let finalText = "";
    let errored = false;
    rec.onstart = () => setListening(true);
    rec.onresult = (e) => {
      let t = "";
      for (let k = 0; k < e.results.length; k++) t += e.results[k][0].transcript;
      finalText = t;
      setText(t); // recognised speech goes into the same command box the user types in
    };
    rec.onerror = (e) => {
      errored = true;
      setListening(false);
      if (e.error !== "aborted") setProblem(describeSpeechError(e.error, lang));
    };
    rec.onend = () => {
      setListening(false);
      if (errored) return;
      // Same pipeline as a typed command.
      if (finalText.trim()) void understand(finalText, "mic");
      else setProblem("I didn't catch anything. Tap the mic and try again, or type your command.");
    };
    recRef.current = rec;
    try {
      rec.start();
    } catch (err) {
      setListening(false);
      setProblem(`Couldn't start speech recognition: ${err instanceof Error ? err.message : String(err)}`);
    }
  };

  const lowItems = state?.products.filter((p) => p.low) ?? [];

  return (
    <div className="mx-auto w-full max-w-xl pb-16">
      <header className="bg-gradient-to-br from-primary to-teal-900 px-4 pb-14 pt-6 text-primary-ink">
        <p className="text-sm opacity-80">{state?.shopName ?? "Lakshmi Kirana Store"}</p>
        <h1 className="mt-1 text-3xl font-bold tracking-tight">Stockbol</h1>
        <p className="mt-1 text-sm opacity-90">Speak or type. Check what I understood. Confirm. Done.</p>
      </header>

      <div className="-mt-10 space-y-4 px-4">
        <section className="rounded-card border border-line bg-surface p-4 shadow-lg shadow-black/5">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              void understand(text, "typed");
            }}
            className="flex items-center gap-2"
          >
            <input
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder={listening ? "Listening…" : "e.g. Add 5 bags of rice"}
              aria-label="Stock command"
              className="min-h-12 w-full min-w-0 flex-1 rounded-xl border border-line bg-canvas px-3 text-base outline-none focus:border-primary focus:ring-2 focus:ring-primary/30"
            />
            <button
              type="button"
              onClick={() => void toggleMic()}
              aria-label={listening ? "Stop listening" : "Speak a command"}
              aria-busy={micStarting}
              title={
                micStarting
                  ? "Waiting for microphone permission…"
                  : micSupported
                    ? "Speak a command"
                    : "This browser may not support speech recognition — click to see details"
              }
              className={`flex size-12 shrink-0 items-center justify-center rounded-full text-primary-ink transition ${
                listening
                  ? "animate-pulse bg-danger ring-4 ring-danger/30"
                  : micStarting
                    ? "animate-pulse bg-primary/70"
                    : micSupported
                      ? "bg-primary hover:brightness-110"
                      : "bg-primary/50"
              }`}
            >
              <svg viewBox="0 0 24 24" className="size-6" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                <rect x="9" y="3" width="6" height="11" rx="3" />
                <path d="M5 11a7 7 0 0 0 14 0M12 18v3" />
              </svg>
            </button>
          </form>

          {(listening || micStarting) && (
            <div className="mt-3 flex items-center gap-3 rounded-xl bg-danger-bg px-3 py-2 text-danger" role="status" aria-live="polite">
              <span className="relative flex size-3 shrink-0">
                <span className="absolute inline-flex size-full animate-ping rounded-full bg-danger opacity-75" />
                <span className="relative inline-flex size-3 rounded-full bg-danger" />
              </span>
              <span className="font-semibold">{listening ? "Listening… speak now" : "Allow the microphone to start…"}</span>
              {listening && <span className="text-sm text-ink-muted">{LANGS.find((l) => l.code === lang)?.label} · tap mic to stop</span>}
            </div>
          )}

          <div className="mt-3 flex items-center justify-between gap-2">
            <div className="flex gap-1" role="group" aria-label="Speech language">
              {LANGS.map((l) => (
                <button
                  key={l.code}
                  type="button"
                  onClick={() => setLang(l.code)}
                  aria-pressed={lang === l.code}
                  className={`min-h-9 rounded-full border px-3 text-sm ${
                    lang === l.code ? "border-primary bg-primary text-primary-ink" : "border-line bg-surface text-ink-muted"
                  }`}
                >
                  {l.label}
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={() => void understand(text, "typed")}
              disabled={busy || !text.trim()}
              className="min-h-10 rounded-xl bg-ink px-4 text-sm font-medium text-white disabled:opacity-40"
            >
              {busy && !pending ? "Understanding…" : "Understand"}
            </button>
          </div>

          <div className="mt-3 flex flex-wrap gap-2">
            {EXAMPLES.map((ex) => (
              <button
                key={ex}
                type="button"
                onClick={() => {
                  setText(ex);
                  void understand(ex, "typed");
                }}
                className="rounded-full border border-line bg-canvas px-3 py-1.5 text-sm text-ink-muted hover:border-primary hover:text-ink"
              >
                {ex}
              </button>
            ))}
          </div>
        </section>

        <div className="flex gap-3 rounded-card border border-attention/30 bg-attention-bg p-3 text-sm text-attention" role="note">
          <span aria-hidden className="text-lg leading-none">ℹ️</span>
          <p>
            <strong>Basic Mode:</strong> typed commands always work — even if the microphone or AI is unavailable. Commands are
            understood with built-in rules, so nothing here needs an internet AI service.
          </p>
        </div>

        {problem && (
          <div className="rounded-card border border-danger/30 bg-danger-bg p-4" role="alert">
            <p className="font-semibold text-danger">I need a bit more help</p>
            <p className="mt-1 text-sm text-ink">{problem}</p>
            <p className="mt-1 text-xs text-ink-muted">Nothing was changed.</p>
          </div>
        )}

        {pending && (
          <section className="rounded-card border-2 border-primary bg-surface p-4 shadow-lg shadow-primary/10" aria-live="polite">
            <p className="text-xs font-medium uppercase tracking-wide text-ink-muted">Here&apos;s what I understood</p>
            <p className="mt-1 text-2xl font-bold leading-tight">{pending.i.summary}</p>
            <p className="mt-2 text-sm text-ink-muted">
              You said: <span className="text-ink">“{pending.said}”</span>
            </p>
            <div className="mt-3 flex items-center gap-2 rounded-xl bg-canvas p-3 text-base">
              <span className="text-ink-muted">Stock</span>
              <strong>{pending.i.stockBeforeText}</strong>
              <span aria-hidden>→</span>
              <strong className={pending.i.op === "add" ? "text-ok" : "text-attention"}>{pending.i.stockAfterText}</strong>
            </div>
            {pending.i.unitAssumed && (
              <p className="mt-2 text-sm text-attention">No unit heard — using {pending.i.productName}&apos;s usual unit.</p>
            )}
            {pending.i.willBeLow && (
              <p className="mt-2 text-sm font-medium text-attention">⚠ This will leave {pending.i.productName} low on stock.</p>
            )}
            <div className="mt-4 grid grid-cols-2 gap-3">
              <button type="button" onClick={() => setPending(null)} disabled={busy} className="min-h-12 rounded-xl border border-line bg-surface font-medium">
                Cancel
              </button>
              <button
                type="button"
                onClick={() => void confirm()}
                disabled={busy}
                className="min-h-12 rounded-xl bg-primary font-semibold text-primary-ink hover:brightness-110 disabled:opacity-60"
              >
                {busy ? "Saving…" : "Confirm"}
              </button>
            </div>
          </section>
        )}

        {toast && (
          <div
            className={`flex items-center justify-between gap-3 rounded-card border p-3 ${
              toast.tone === "ok" ? "border-ok/30 bg-ok-bg text-ok" : "border-line bg-surface text-ink"
            }`}
            role="status"
          >
            <p className="font-medium">
              {toast.tone === "ok" ? "✓ " : "↩ "}
              {toast.message}
            </p>
            {toast.canUndo && (
              <button type="button" onClick={() => void undo()} disabled={busy} className="min-h-10 shrink-0 rounded-lg border border-ok/40 bg-surface px-3 text-sm font-semibold">
                Undo
              </button>
            )}
          </div>
        )}

        {lowItems.length > 0 && (
          <div className="rounded-card border border-attention/30 bg-attention-bg p-3 text-attention">
            <p className="font-semibold">⚠ Needs attention ({lowItems.length})</p>
            <p className="text-sm">{lowItems.map((p) => `${p.name}: ${p.stockText} left (below ${p.thresholdText})`).join(" · ")}</p>
          </div>
        )}

        <section>
          <h2 className="mb-2 text-sm font-semibold uppercase tracking-wide text-ink-muted">Current stock</h2>
          {loadError && <p className="rounded-card bg-danger-bg p-3 text-sm text-danger">{loadError}</p>}
          <div className="grid grid-cols-2 gap-3">
            {(state?.products ?? []).map((p) => (
              <article
                key={p.id}
                className={`rounded-card border bg-surface p-4 transition ${p.low ? "border-attention/50" : "border-line"} ${flashId === p.id ? "flash" : ""}`}
              >
                <div className="flex items-start justify-between gap-2">
                  <h3 className="text-base font-semibold">{p.name}</h3>
                  {p.low ? (
                    <span className="rounded-full bg-attention-bg px-2 py-0.5 text-xs font-semibold text-attention">▼ Low</span>
                  ) : (
                    <span className="rounded-full bg-ok-bg px-2 py-0.5 text-xs font-semibold text-ok">✓ OK</span>
                  )}
                </div>
                <p className="mt-2 text-4xl font-bold leading-none">{p.qty}</p>
                <p className="mt-1 text-sm text-ink-muted">{p.unit}</p>
              </article>
            ))}
            {!state && !loadError && [0, 1, 2, 3].map((k) => <div key={k} className="h-32 animate-pulse rounded-card bg-line/60" />)}
          </div>
        </section>

        <section>
          <div className="mb-2 flex items-center justify-between">
            <h2 className="text-sm font-semibold uppercase tracking-wide text-ink-muted">Recent activity</h2>
            {state?.undoTarget && (
              <button type="button" onClick={() => void undo()} disabled={busy} className="min-h-9 rounded-lg border border-line bg-surface px-3 text-sm font-medium">
                ↩ Undo {state.undoTarget.label}
              </button>
            )}
          </div>
          <ul className="divide-y divide-line overflow-hidden rounded-card border border-line bg-surface">
            {(state?.recent ?? []).length === 0 && <li className="p-4 text-sm text-ink-muted">No changes yet. Try a command above.</li>}
            {(state?.recent ?? []).map((t) => (
              <li key={t.id} className={`flex items-center justify-between gap-3 p-3 ${t.reverted ? "opacity-50" : ""}`}>
                <div className="min-w-0">
                  <p className={`font-semibold ${t.reverted ? "line-through" : ""}`}>
                    <span className={t.kind === "add" ? "text-ok" : t.kind === "remove" ? "text-attention" : "text-ink-muted"}>{t.deltaText}</span>{" "}
                    {t.productName}
                  </p>
                  <p className="text-xs text-ink-muted">
                    {t.kind === "undo" ? "Undo" : t.source === "voice" ? "🎤 Voice" : "⌨ Typed"} · now {t.stockAfterText}
                    {t.reverted ? " · undone" : ""}
                  </p>
                </div>
                <time className="shrink-0 text-xs text-ink-muted" dateTime={t.createdAt}>
                  {new Date(t.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </time>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </div>
  );
}
