import type { ReactNode } from "react";

/** Mobile-first page container (UX_SPEC §3): 16 px gutters, centred column that scales up. */
export function PageShell({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-xl flex-col">
      <header className="border-b border-line bg-surface px-4 py-3">
        <h1 className="text-lg font-semibold">{title}</h1>
      </header>
      <main className="flex flex-1 flex-col gap-4 px-4 py-6">{children}</main>
    </div>
  );
}
